# État des fonctionnalités (honnête)

## Vérifié par des tests automatiques (backend, 17 tests passent)
Authentification par jeton signé · limites de débit par IP et par appareil · quota journalier · validation des entrées · limites de taille · en-têtes de sécurité · la clé OpenRouter n'apparaît dans aucune réponse · erreurs fournisseur (429, 401, modèle sans vision) · chat avec prompts par mode · extraction TXT / DOCX / PDF · analyse de document · analyse d'image (format vérifié) · conversations côté serveur · réponse 501 pour la génération d'images.
Ces tests utilisent un **faux** fournisseur IA : le vrai appel à OpenRouter n'a pas été testé.

## Écrit mais PAS compilé ni exécuté
Toute l'application Android. L'environnement de création n'avait ni Android SDK, ni Gradle, ni accès Internet. Ont été contrôlés : XML bien formé, délimiteurs Kotlin, imports internes, compatibilité Kotlin/Compose. La première vraie compilation sera celle de GitHub Actions : s'il reste une erreur, le journal indiquera le fichier et la ligne.

## Fonctionnalités prévues dans l'application
Écran de démarrage · accueil · assistant IA · assistant développeur (blocs de code, coloration légère, copie) · générateur d'idées · rédaction · traduction · documents (PDF/TXT/DOCX) · images · historique local avec suppression confirmée · paramètres (adresse du serveur, test de connexion, mode sombre) · à propos.

## Restant / limites
- Génération d'images : non connectée (le backend répond 501).
- L'application garde son historique sur le téléphone ; les routes de conversations du backend existent mais ne sont pas utilisées par l'application.
- Réponses affichées d'un bloc (pas de streaming).
- Les PDF scannés (images) ne contiennent pas de texte extractible.
- Modèles gratuits OpenRouter : disponibilité et quotas variables, aucune garantie.
- Authentification : jeton anonyme par appareil. Pour une ouverture publique large, ajouter des comptes utilisateurs.
- Pas de tests automatisés de l'interface Android.
- APK Debug uniquement (pas de signature de publication / Play Store).
