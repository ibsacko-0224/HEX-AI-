# HEX-AI — CENTRAL-HEX

> « L'innovation commence par une idée. »

Application Android (Kotlin + Jetpack Compose + Material 3) et backend Node.js qui sert d'intermédiaire sécurisé vers OpenRouter.

```
HEX-AI/
├── (build.yml à créer à part dans .github/workflows/)
├── app/                          # application Android
├── backend/                      # serveur Node.js (voir backend/README.md)
├── docs/FONCTIONNALITES.md       # état honnête : terminé / restant
├── build.gradle · settings.gradle · gradle.properties
└── README.md
```

## Mise en route depuis un téléphone

1. **Dépôt GitHub** : envoie *le contenu* de ce dossier à la racine d'un dépôt (pas le zip lui-même). Vérifie que `app/`, `backend/` et `.github/` sont bien là.
2. **Backend** : déploie `backend/` (voir `backend/README.md`) avec `OPENROUTER_API_KEY` et `AUTH_SECRET` dans l'hébergeur.
3. **Adresse du backend dans l'APK** : GitHub → *Settings → Secrets and variables → Actions → onglet **Variables*** → crée `HEX_API_URL` = `https://ton-backend` (c'est une adresse publique, pas un secret). Sinon, saisis-la dans *Paramètres* de l'application.
4. **Compiler** : onglet *Actions* → *Build HEX-AI* → *Run workflow*. L'APK est dans les *Artifacts* et dans les *Releases*.

## Secrets : qui voit quoi

| Valeur | Où la mettre | Dans l'APK ? |
|---|---|---|
| `OPENROUTER_API_KEY` | Variables d'environnement de **l'hébergeur du backend** | Jamais |
| `AUTH_SECRET` | Variables d'environnement de **l'hébergeur du backend** | Jamais |
| `HEX_API_URL` | **Variable** GitHub Actions (publique) | Oui (simple adresse) |

Les *GitHub Actions Secrets* ne servent pas à faire tourner le backend en production : ce sont deux endroits différents.

## Versions (vérifiées compatibles)

AGP 8.5.2 · Gradle 8.7 · Java 17 · Kotlin 1.9.24 · Compose Compiler 1.5.14 · Compose BOM 2024.06.00 · compileSdk/targetSdk 34 · minSdk 26.
Le dépôt n'inclut pas `gradle-wrapper.jar` ; le workflow installe Gradle 8.7 lui-même.
