package com.centralhex.hexai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.centralhex.hexai.MainViewModel

data class ModeInfo(
    val key: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val hints: List<String>
)

val CHAT_MODES = listOf(
    ModeInfo(
        "chat", "Assistant IA", "Pose n'importe quelle question", Icons.Filled.Chat,
        listOf("Explique-moi simplement comment fonctionne l'IA", "Donne-moi un plan pour apprendre le code en 30 jours", "Résume les avantages du travail en équipe")
    ),
    ModeInfo(
        "dev", "Assistant développeur", "Code, bugs, projets complets", Icons.Filled.Code,
        listOf("Écris une page HTML/CSS responsive avec un formulaire de contact", "Explique ce code et corrige les erreurs : ", "Génère une API Node.js avec Express et une route /health")
    ),
    ModeInfo(
        "ideas", "Générateur d'idées", "Apps, sites, business, bots, projets IA", Icons.Filled.Lightbulb,
        listOf("10 idées de bots WhatsApp utiles en Afrique de l'Ouest", "Idées de business numérique à lancer avec peu de budget", "Donne-moi un plan de développement pour une application mobile")
    ),
    ModeInfo(
        "writing", "Assistant rédaction", "Textes, corrections, messages", Icons.Filled.Edit,
        listOf("Rédige une publication pour présenter ma communauté tech", "Corrige et améliore ce texte : ", "Écris un message WhatsApp professionnel pour relancer un client")
    )
)

fun modeInfo(key: String): ModeInfo = CHAT_MODES.firstOrNull { it.key == key } ?: CHAT_MODES[0]

@Composable
fun ChatScreen(vm: MainViewModel, mode: String, onBack: () -> Unit) {
    val info = modeInfo(mode)
    LaunchedEffect(mode) { vm.ensureConversation(mode) }

    val messages = vm.current?.messages.orEmpty()
    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size, vm.loading) {
        val last = messages.size - 1 + (if (vm.loading) 1 else 0)
        if (last >= 0) listState.animateScrollToItem(last)
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = info.title,
            subtitle = info.subtitle,
            onBack = onBack,
            actions = {
                IconButton(onClick = { vm.newConversation(mode) }, enabled = !vm.loading) {
                    Icon(Icons.Filled.Add, contentDescription = "Nouvelle conversation")
                }
            }
        )
        Box(Modifier.weight(1f)) {
            if (messages.isEmpty()) {
                EmptyState(info) { input = it }
            } else {
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(messages) { MessageBubble(it) }
                    if (vm.loading) item { TypingIndicator() }
                }
            }
        }
        vm.error?.let { ErrorBanner(it, onRetry = { vm.retry() }, onDismiss = { vm.dismissError() }) }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { if (it.length <= 7000) input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Écris ton message…") },
                shape = RoundedCornerShape(24.dp),
                maxLines = 5,
                enabled = !vm.loading
            )
            Spacer(Modifier.size(8.dp))
            FilledIconButton(
                onClick = {
                    vm.send(input)
                    input = ""
                },
                enabled = input.isNotBlank() && !vm.loading
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Envoyer")
            }
        }
    }
}

@Composable
private fun EmptyState(info: ModeInfo, onPick: (String) -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(info.icon, contentDescription = null, modifier = Modifier.size(44.dp))
        Spacer(Modifier.height(12.dp))
        Text("Comment puis-je t'aider ?", fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(4.dp))
        Text(
            "L'innovation commence par une idée.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(20.dp))
        info.hints.forEach { hint ->
            Box(
                Modifier
                    .padding(vertical = 4.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable { onPick(hint) }
                    .padding(14.dp)
            ) {
                Text(hint, fontSize = 14.sp)
            }
        }
    }
}
