package com.centralhex.hexai.data

import android.util.Base64
import com.centralhex.hexai.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit

class ApiException(message: String, val code: String = "error", val status: Int = 0) : Exception(message)

data class DocText(val text: String, val truncated: Boolean)

/** Client du backend HEX-AI. Aucune clé fournisseur ici : seulement un jeton d'appareil. */
class Api(private val prefs: Prefs) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val json = "application/json; charset=utf-8".toMediaType()

    fun baseUrl(): String =
        (if (prefs.apiUrl.isNotBlank()) prefs.apiUrl else BuildConfig.DEFAULT_API_URL).trim().trimEnd('/')

    suspend fun health(): JSONObject = withContext(Dispatchers.IO) {
        val base = requireBase()
        val req = try {
            Request.Builder().url("$base/api/health").get().build()
        } catch (e: IllegalArgumentException) {
            throw ApiException("Adresse du serveur invalide.", "bad_url")
        }
        execute(req)
    }

    suspend fun chat(mode: String, messages: List<ChatMessage>, language: String?): String {
        val arr = JSONArray()
        messages.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject().put("mode", mode).put("messages", arr)
        if (!language.isNullOrBlank()) body.put("language", language)
        return post("/api/chat", body).getString("reply")
    }

    suspend fun extractDocument(filename: String, bytes: ByteArray): DocText {
        val body = JSONObject()
            .put("filename", filename)
            .put("dataBase64", Base64.encodeToString(bytes, Base64.NO_WRAP))
        val r = post("/api/documents/extract", body)
        return DocText(r.getString("text"), r.optBoolean("truncated", false))
    }

    suspend fun askDocument(text: String, question: String?): String {
        val body = JSONObject().put("text", text)
        if (!question.isNullOrBlank()) body.put("question", question)
        return post("/api/documents/ask", body).getString("reply")
    }

    suspend fun analyzeImage(jpegOrPng: ByteArray, question: String?): String {
        val body = JSONObject().put("imageBase64", Base64.encodeToString(jpegOrPng, Base64.NO_WRAP))
        if (!question.isNullOrBlank()) body.put("question", question)
        return post("/api/vision", body).getString("reply")
    }

    // ---- interne

    private fun requireBase(): String {
        val base = baseUrl()
        if (base.isBlank()) {
            throw ApiException("Adresse du serveur non configurée. Ouvre Paramètres pour l'ajouter.", "no_server")
        }
        return base
    }

    private suspend fun register() {
        val r = rawPost("/api/auth/register", JSONObject(), null)
        val t = r.optString("token")
        if (t.isBlank()) throw ApiException("Réponse d'inscription invalide.", "bad_response")
        prefs.token = t
    }

    private suspend fun post(path: String, body: JSONObject): JSONObject {
        if (prefs.token.isBlank()) register()
        return try {
            rawPost(path, body, prefs.token)
        } catch (e: ApiException) {
            if (e.status == 401) {
                prefs.token = ""
                register()
                rawPost(path, body, prefs.token)
            } else {
                throw e
            }
        }
    }

    private suspend fun rawPost(path: String, body: JSONObject, token: String?): JSONObject =
        withContext(Dispatchers.IO) {
            val base = requireBase()
            val req = try {
                val b = Request.Builder().url(base + path).post(body.toString().toRequestBody(json))
                if (token != null) b.header("Authorization", "Bearer $token")
                b.build()
            } catch (e: IllegalArgumentException) {
                throw ApiException("Adresse du serveur invalide.", "bad_url")
            }
            execute(req)
        }

    private fun execute(req: Request): JSONObject {
        val result: JSONObject = try {
            client.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                val parsed = try { JSONObject(text) } catch (e: Exception) { null }
                if (!resp.isSuccessful) {
                    val err = parsed?.optJSONObject("error")
                    val msg = err?.optString("message")
                    throw ApiException(
                        if (!msg.isNullOrBlank()) msg else "Erreur du serveur (${resp.code}).",
                        err?.optString("code") ?: "http_${resp.code}",
                        resp.code
                    )
                }
                parsed ?: throw ApiException("Réponse du serveur illisible.", "bad_response")
            }
        } catch (e: ApiException) {
            throw e
        } catch (e: SocketTimeoutException) {
            throw ApiException("Le serveur met trop de temps à répondre. Réessaie.", "timeout")
        } catch (e: IOException) {
            throw ApiException("Connexion impossible. Vérifie Internet et l'adresse du serveur.", "network")
        }
        return result
    }
}
