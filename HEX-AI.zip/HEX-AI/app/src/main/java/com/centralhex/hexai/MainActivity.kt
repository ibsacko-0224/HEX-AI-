package com.centralhex.hexai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.centralhex.hexai.ui.HexApp
import com.centralhex.hexai.ui.HexTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MainViewModel = viewModel()
            HexTheme(dark = vm.dark) {
                HexApp(vm)
            }
        }
    }
}
