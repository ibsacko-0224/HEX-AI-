package com.centralhex.hexai.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.centralhex.hexai.BuildConfig
import com.centralhex.hexai.MainViewModel
import com.centralhex.hexai.data.ApiException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------- 1. Démarrage

@Composable
fun SplashScreen(onDone: () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    val alpha by animateFloatAsState(if (visible) 1f else 0f, tween(900), label = "splash")
    LaunchedEffect(Unit) {
        visible = true
        delay(1500)
        onDone()
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(Modifier.alpha(alpha), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("HEX-AI", fontSize = 44.sp, fontWeight = FontWeight.Black, letterSpacing = 6.sp)
            Spacer(Modifier.height(10.dp))
            Text("CENTRAL-HEX", fontSize = 13.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(28.dp))
            Text(
                "L'innovation commence par une idée.",
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ---------------------------------------------------------------- 2. Accueil

private data class Tile(val title: String, val subtitle: String, val icon: ImageVector, val route: String)

private val TILES: List<Tile> = CHAT_MODES.map { Tile(it.title, it.subtitle, it.icon, "chat/${it.key}") } + listOf(
    Tile("Traduction", "FR, EN, ES, PT et plus", Icons.Filled.Translate, "translate"),
    Tile("Documents", "PDF, TXT, DOCX", Icons.Filled.Description, "docs"),
    Tile("Images", "Analyse visuelle", Icons.Filled.Image, "images")
)

@Composable
fun HomeScreen(onNavigate: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 8.dp)) {
            Text("HEX-AI", fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text("L'innovation commence par une idée.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(TILES) { tile ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigate(tile.route) },
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(tile.icon, contentDescription = null, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.height(6.dp))
                        Text(tile.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(tile.subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- 9. Historique

@Composable
fun HistoryScreen(vm: MainViewModel, onOpen: (String) -> Unit) {
    var toDelete by remember { mutableStateOf<String?>(null) }
    val format = remember { SimpleDateFormat("dd MMM · HH:mm", Locale.getDefault()) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Historique", "${vm.conversations.size} conversation(s)")
        if (vm.conversations.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Aucune conversation pour le moment.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(vm.conversations, key = { it.id }) { conv ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpen(conv.id) },
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(conv.title, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text(
                                    "${modeInfo(conv.mode).title} · ${format.format(Date(conv.updatedAt))}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { toDelete = conv.id }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Supprimer")
                            }
                        }
                    }
                }
            }
        }
    }

    toDelete?.let { id ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Supprimer cette conversation ?") },
            text = { Text("Cette action est définitive.") },
            confirmButton = { TextButton(onClick = { vm.delete(id); toDelete = null }) { Text("Supprimer") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Annuler") } }
        )
    }
}

// ---------------------------------------------------------------- 10. Paramètres

@Composable
fun SettingsScreen(vm: MainViewModel, onAbout: () -> Unit) {
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf(vm.apiUrl.ifBlank { BuildConfig.DEFAULT_API_URL }) }
    var status by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Paramètres")
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Serveur HEX-AI", fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = url,
                onValueChange = { url = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Adresse du backend (https://…)") },
                singleLine = true,
                shape = RoundedCornerShape(18.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { vm.setApiUrl(url); status = "Adresse enregistrée." }) { Text("Enregistrer") }
                OutlinedButton(
                    enabled = !testing,
                    onClick = {
                        vm.setApiUrl(url)
                        testing = true
                        status = "Test en cours…"
                        scope.launch {
                            try {
                                val h = vm.api.health()
                                status = if (h.optBoolean("aiConfigured")) "✅ Serveur joignable, IA configurée." else "⚠️ Serveur joignable, mais la clé IA n'est pas configurée."
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: ApiException) {
                                status = "❌ ${e.message}"
                            } catch (e: Exception) {
                                status = "❌ Erreur inattendue."
                            } finally {
                                testing = false
                            }
                        }
                    }
                ) { Text("Tester la connexion") }
            }
            status?.let { Text(it, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }

            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Mode sombre", fontWeight = FontWeight.Bold)
                    Text("Activé par défaut", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = vm.dark, onCheckedChange = { vm.setDark(it) })
            }

            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { confirmClear = true }, modifier = Modifier.fillMaxWidth()) { Text("Supprimer tout l'historique") }
            OutlinedButton(onClick = onAbout, modifier = Modifier.fillMaxWidth()) { Text("À propos de HEX-AI") }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Tout supprimer ?") },
            text = { Text("Toutes les conversations enregistrées sur ce téléphone seront effacées.") },
            confirmButton = { TextButton(onClick = { vm.clearAll(); confirmClear = false }) { Text("Supprimer") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Annuler") } }
        )
    }
}

// ---------------------------------------------------------------- 11. À propos

@Composable
fun AboutScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("À propos", onBack = onBack)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("HEX-AI", fontSize = 32.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text("Version ${BuildConfig.VERSION_NAME}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Une application de l'écosystème CENTRAL-HEX.")
            Text("L'innovation commence par une idée.", fontWeight = FontWeight.SemiBold)
            Text(
                "HEX-AI passe par un serveur sécurisé : aucune clé d'API n'est stockée dans l'application. " +
                    "Les réponses viennent d'un modèle d'IA ; elles peuvent contenir des erreurs, vérifie les informations importantes. " +
                    "La disponibilité et les quotas des modèles gratuits peuvent changer.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
