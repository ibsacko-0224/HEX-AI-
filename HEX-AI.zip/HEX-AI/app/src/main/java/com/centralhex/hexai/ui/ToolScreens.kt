package com.centralhex.hexai.ui

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.centralhex.hexai.MainViewModel
import com.centralhex.hexai.data.ApiException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

private fun errorText(e: Exception): String =
    if (e is ApiException) (e.message ?: "Erreur") else "Erreur inattendue : ${e.message}"

@Composable
private fun ResultCard(text: String) {
    val context = LocalContext.current
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp)) {
            FormattedText(text)
            Spacer(Modifier.height(6.dp))
            OutlinedButton(onClick = { copyToClipboard(context, text) }) {
                Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.size(6.dp))
                Text("Copier")
            }
        }
    }
}

// ---------------------------------------------------------------- Traduction

private val LANGUAGES = listOf("Français", "Anglais", "Espagnol", "Portugais", "Arabe", "Allemand", "Italien", "Chinois", "Russe", "Turc", "Swahili")

@Composable
fun TranslateScreen(vm: MainViewModel, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var source by rememberSaveable { mutableStateOf("") }
    var language by rememberSaveable { mutableStateOf("Anglais") }
    var custom by rememberSaveable { mutableStateOf("") }
    var result by rememberSaveable { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Traduction", "Traduis vers n'importe quelle langue", onBack)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = source,
                onValueChange = { if (it.length <= 7000) source = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 140.dp),
                label = { Text("Texte à traduire") },
                shape = RoundedCornerShape(18.dp)
            )
            Text("Traduire vers", fontWeight = FontWeight.SemiBold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(LANGUAGES) { l ->
                    FilterChip(selected = custom.isBlank() && language == l, onClick = { language = l; custom = "" }, label = { Text(l) })
                }
            }
            OutlinedTextField(
                value = custom,
                onValueChange = { if (it.length <= 40) custom = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Autre langue (optionnel)") },
                singleLine = true,
                shape = RoundedCornerShape(18.dp)
            )
            Button(
                onClick = {
                    error = null
                    loading = true
                    val target = if (custom.isNotBlank()) custom.trim() else language
                    scope.launch {
                        try {
                            result = vm.api.chat("translate", listOf(com.centralhex.hexai.data.ChatMessage("user", source.trim())), target)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            error = errorText(e)
                        } finally {
                            loading = false
                        }
                    }
                },
                enabled = source.isNotBlank() && !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("Traduire")
            }
            error?.let { ErrorBanner(it, onDismiss = { error = null }) }
            if (result.isNotBlank()) ResultCard(result)
        }
    }
}

// ---------------------------------------------------------------- Documents

@Composable
fun DocumentScreen(vm: MainViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var fileName by remember { mutableStateOf<String?>(null) }
    var docText by remember { mutableStateOf<String?>(null) }
    var truncated by remember { mutableStateOf(false) }
    var question by rememberSaveable { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val answers = remember { mutableStateListOf<Pair<String, String>>() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        error = null
        loading = true
        scope.launch {
            try {
                val name = displayName(context, uri)
                val bytes = readBytesLimited(context, uri, 8 * 1024 * 1024)
                val doc = vm.api.extractDocument(name, bytes)
                fileName = name
                docText = doc.text
                truncated = doc.truncated
                answers.clear()
                answers.add("Résumé" to vm.api.askDocument(doc.text, null))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = errorText(e)
            } finally {
                loading = false
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Analyse de documents", "PDF, TXT et DOCX", onBack)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = {
                    picker.launch(
                        arrayOf(
                            "application/pdf",
                            "text/plain",
                            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        )
                    )
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.AttachFile, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.size(8.dp))
                Text(if (fileName == null) "Choisir un document" else "Changer de document")
            }
            if (loading) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    Text("Analyse en cours…")
                }
            }
            error?.let { ErrorBanner(it, onDismiss = { error = null }) }
            fileName?.let { Text("📄 $it", fontWeight = FontWeight.SemiBold) }
            if (truncated) {
                Text(
                    "Document long : seule la première partie a été analysée.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            answers.forEach { (q, a) ->
                Text(q, fontWeight = FontWeight.Bold)
                ResultCard(a)
            }
            if (docText != null) {
                OutlinedTextField(
                    value = question,
                    onValueChange = { if (it.length <= 2000) question = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Pose une question sur le document") },
                    shape = RoundedCornerShape(18.dp)
                )
                Button(
                    onClick = {
                        val q = question.trim()
                        val text = docText ?: return@Button
                        error = null
                        loading = true
                        scope.launch {
                            try {
                                answers.add(q to vm.api.askDocument(text, q))
                                question = ""
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                error = errorText(e)
                            } finally {
                                loading = false
                            }
                        }
                    },
                    enabled = question.isNotBlank() && !loading,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Demander") }
            }
        }
    }
}

// ---------------------------------------------------------------- Images

@Composable
fun ImageScreen(vm: MainViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var imageBytes by remember { mutableStateOf<ByteArray?>(null) }
    var question by rememberSaveable { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            imageBytes = prepareImage(context, uri)
            result = ""
            error = null
        } catch (e: Exception) {
            error = errorText(e)
        }
    }

    val preview = remember(imageBytes) {
        imageBytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Analyse d'images", "Choisis une photo et pose une question", onBack)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(onClick = { picker.launch("image/*") }, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.size(8.dp))
                Text(if (imageBytes == null) "Choisir une image" else "Changer d'image")
            }
            if (preview != null) {
                Image(
                    bitmap = preview,
                    contentDescription = "Image sélectionnée",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 280.dp)
                        .clip(RoundedCornerShape(18.dp))
                )
                OutlinedTextField(
                    value = question,
                    onValueChange = { if (it.length <= 2000) question = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Question (vide = décrire l'image)") },
                    shape = RoundedCornerShape(18.dp)
                )
                Button(
                    onClick = {
                        val bytes = imageBytes ?: return@Button
                        error = null
                        loading = true
                        scope.launch {
                            try {
                                result = vm.api.analyzeImage(bytes, question.trim())
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                error = errorText(e)
                            } finally {
                                loading = false
                            }
                        }
                    },
                    enabled = !loading,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("Analyser")
                }
            }
            error?.let { ErrorBanner(it, onDismiss = { error = null }) }
            if (result.isNotBlank()) ResultCard(result)
        }
    }
}
