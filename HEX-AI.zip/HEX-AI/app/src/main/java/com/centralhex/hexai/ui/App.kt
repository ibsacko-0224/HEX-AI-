package com.centralhex.hexai.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.centralhex.hexai.MainViewModel

private data class BottomItem(val label: String, val route: String, val icon: ImageVector)

private val BOTTOM_ITEMS = listOf(
    BottomItem("Accueil", "home", Icons.Filled.Home),
    BottomItem("Assistant", "chat/chat", Icons.Filled.Chat),
    BottomItem("Historique", "history", Icons.Filled.History),
    BottomItem("Réglages", "settings", Icons.Filled.Settings)
)

private fun NavHostController.goTab(route: String) {
    navigate(route) {
        popUpTo("home")
        launchSingleTop = true
    }
}

@Composable
fun HexApp(vm: MainViewModel) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (route != null && route != "splash") {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    BOTTOM_ITEMS.forEach { item ->
                        val selected = if (item.route.startsWith("chat")) route.startsWith("chat") else route == item.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = { nav.goTab(item.route) },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                                selectedTextColor = MaterialTheme.colorScheme.onSurface,
                                indicatorColor = MaterialTheme.colorScheme.primary,
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }
        }
    ) { inner ->
        Box(Modifier.fillMaxSize().padding(inner)) {
            NavHost(navController = nav, startDestination = "splash") {
                composable("splash") {
                    SplashScreen {
                        nav.navigate("home") { popUpTo("splash") { inclusive = true } }
                    }
                }
                composable("home") { HomeScreen { nav.navigate(it) { launchSingleTop = true } } }
                composable(
                    "chat/{mode}",
                    arguments = listOf(navArgument("mode") { type = NavType.StringType })
                ) { back ->
                    ChatScreen(vm, back.arguments?.getString("mode") ?: "chat") { nav.popBackStack() }
                }
                composable("translate") { TranslateScreen(vm) { nav.popBackStack() } }
                composable("docs") { DocumentScreen(vm) { nav.popBackStack() } }
                composable("images") { ImageScreen(vm) { nav.popBackStack() } }
                composable("history") {
                    HistoryScreen(vm) { id ->
                        vm.open(id)
                        val mode = vm.current?.mode ?: "chat"
                        nav.navigate("chat/$mode") { launchSingleTop = true }
                    }
                }
                composable("settings") { SettingsScreen(vm) { nav.navigate("about") } }
                composable("about") { AboutScreen { nav.popBackStack() } }
            }
        }
    }
}
