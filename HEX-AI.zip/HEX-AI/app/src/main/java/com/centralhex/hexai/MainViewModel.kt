package com.centralhex.hexai

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.centralhex.hexai.data.Api
import com.centralhex.hexai.data.ApiException
import com.centralhex.hexai.data.ChatMessage
import com.centralhex.hexai.data.Conversation
import com.centralhex.hexai.data.LocalStore
import com.centralhex.hexai.data.Prefs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    val api = Api(prefs)
    private val store = LocalStore(app)

    var conversations by mutableStateOf(store.load().sortedByDescending { it.updatedAt })
        private set
    var current by mutableStateOf<Conversation?>(null)
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var dark by mutableStateOf(prefs.dark)
        private set
    var apiUrl by mutableStateOf(prefs.apiUrl)
        private set

    fun setDark(value: Boolean) {
        dark = value
        prefs.dark = value
    }

    fun setApiUrl(value: String) {
        val clean = value.trim()
        apiUrl = clean
        prefs.apiUrl = clean
        prefs.token = "" // un autre serveur = un autre jeton
    }

    fun dismissError() {
        error = null
    }

    fun ensureConversation(mode: String) {
        val c = current
        if (c == null || c.mode != mode) newConversation(mode)
    }

    fun newConversation(mode: String) {
        if (loading) return
        error = null
        current = Conversation(id = UUID.randomUUID().toString(), title = "Nouvelle conversation", mode = mode)
    }

    fun open(id: String) {
        val c = conversations.firstOrNull { it.id == id } ?: return
        error = null
        current = c
    }

    fun delete(id: String) {
        conversations = conversations.filter { it.id != id }
        if (current?.id == id) current = null
        store.save(conversations)
    }

    fun clearAll() {
        conversations = emptyList()
        current = null
        store.save(conversations)
    }

    fun send(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || loading) return
        val base = current ?: return
        val updated = base.copy(
            title = if (base.messages.isEmpty()) trimmed.take(40) else base.title,
            messages = base.messages + ChatMessage("user", trimmed),
            updatedAt = System.currentTimeMillis()
        )
        error = null
        commit(updated)
        request(updated)
    }

    fun retry() {
        val c = current ?: return
        if (loading || c.messages.lastOrNull()?.role != "user") return
        error = null
        request(c)
    }

    private fun request(conv: Conversation) {
        loading = true
        viewModelScope.launch {
            try {
                val reply = api.chat(conv.mode, buildContext(conv.messages), null)
                val latest = conversations.firstOrNull { it.id == conv.id } ?: conv
                commit(
                    latest.copy(
                        messages = latest.messages + ChatMessage("assistant", reply),
                        updatedAt = System.currentTimeMillis()
                    )
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: ApiException) {
                error = e.message
            } catch (e: Exception) {
                error = "Erreur inattendue : ${e.message}"
            } finally {
                loading = false
            }
        }
    }

    /** Respecte les limites du backend : 20 messages, 7900 caractères chacun, ~36 000 au total. */
    private fun buildContext(all: List<ChatMessage>): List<ChatMessage> {
        val picked = ArrayList<ChatMessage>()
        var total = 0
        for (m in all.asReversed()) {
            val content = if (m.content.length > 7900) m.content.take(7900) else m.content
            if (picked.size >= 20 || total + content.length > 36000) break
            total += content.length
            picked.add(m.copy(content = content))
        }
        picked.reverse()
        return picked
    }

    private fun commit(conv: Conversation) {
        if (current?.id == conv.id) current = conv
        conversations = listOf(conv) + conversations.filter { it.id != conv.id }
        store.save(conversations)
    }
}
