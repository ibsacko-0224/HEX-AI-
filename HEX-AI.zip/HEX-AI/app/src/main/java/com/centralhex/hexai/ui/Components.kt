package com.centralhex.hexai.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.centralhex.hexai.data.ChatMessage

// ---------- Mise en forme des réponses (Markdown simplifié + coloration syntaxique légère)

sealed class Block {
    data class Text(val value: String) : Block()
    data class Code(val lang: String, val code: String) : Block()
}

fun parseBlocks(src: String): List<Block> {
    val out = ArrayList<Block>()
    val sb = StringBuilder()
    var inCode = false
    var lang = ""
    for (line in src.lines()) {
        if (line.trimStart().startsWith("```")) {
            if (inCode) {
                out.add(Block.Code(lang, sb.toString().trimEnd('\n')))
                sb.clear()
                inCode = false
            } else {
                if (sb.isNotBlank()) out.add(Block.Text(sb.toString().trim()))
                sb.clear()
                lang = line.trim().removePrefix("```").trim()
                inCode = true
            }
        } else {
            sb.append(line).append('\n')
        }
    }
    if (sb.isNotBlank()) {
        if (inCode) out.add(Block.Code(lang, sb.toString().trimEnd())) else out.add(Block.Text(sb.toString().trim()))
    }
    return out
}

fun inlineFormat(raw: String): AnnotatedString {
    val s = raw.lines().joinToString("\n") { line ->
        if (line.startsWith("#")) "**" + line.trimStart('#').trim() + "**" else line
    }
    return buildAnnotatedString {
        var i = 0
        while (i < s.length) {
            if (s.startsWith("**", i)) {
                val end = s.indexOf("**", i + 2)
                if (end != -1) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(s.substring(i + 2, end)) }
                    i = end + 2
                    continue
                }
            }
            if (s[i] == '`') {
                val end = s.indexOf('`', i + 1)
                if (end != -1) {
                    withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = Color(0x33888888))) {
                        append(s.substring(i + 1, end))
                    }
                    i = end + 1
                    continue
                }
            }
            append(s[i])
            i++
        }
    }
}

private val KEYWORDS = listOf(
    "fun", "val", "var", "class", "object", "interface", "return", "if", "else", "for", "while", "when", "import", "package",
    "function", "const", "let", "async", "await", "def", "from", "try", "catch", "finally", "throw", "new", "null", "true",
    "false", "None", "True", "False", "public", "private", "static", "void", "int", "string", "this", "self", "export",
    "default", "require", "module", "in", "is", "as", "override", "suspend"
)
private val CODE_REGEX = Regex(
    "(\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*')|(//.*|#.*)|\\b(" + KEYWORDS.joinToString("|") + ")\\b|\\b(\\d+(?:\\.\\d+)?)\\b"
)

fun highlight(code: String): AnnotatedString = buildAnnotatedString {
    append(code)
    for (m in CODE_REGEX.findAll(code)) {
        val color = when {
            m.groups[1] != null -> Color(0xFF86EFAC)
            m.groups[2] != null -> Color(0xFF8A8A8A)
            m.groups[3] != null -> Color(0xFFC4B5FD)
            else -> Color(0xFF93C5FD)
        }
        addStyle(SpanStyle(color = color), m.range.first, m.range.last + 1)
    }
}

@Composable
fun CodeBlock(lang: String, code: String) {
    val context = LocalContext.current
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF111111))
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(Color(0xFF1C1C1C))
                .padding(start = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(if (lang.isBlank()) "code" else lang, color = Color(0xFF9A9A9A), fontSize = 12.sp)
            IconButton(onClick = { copyToClipboard(context, code) }) {
                Icon(Icons.Filled.ContentCopy, contentDescription = "Copier le code", tint = Color(0xFFCCCCCC), modifier = Modifier.size(18.dp))
            }
        }
        Text(
            text = highlight(code),
            color = Color(0xFFE5E5E5),
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
            modifier = Modifier
                .horizontalScroll(rememberScrollState())
                .padding(12.dp)
        )
    }
}

@Composable
fun FormattedText(content: String, modifier: Modifier = Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        parseBlocks(content).forEach { block ->
            when (block) {
                is Block.Text -> Text(inlineFormat(block.value), fontSize = 15.sp, lineHeight = 22.sp)
                is Block.Code -> CodeBlock(block.lang, block.code)
            }
        }
    }
}

// ---------- Éléments d'interface communs

@Composable
fun MessageBubble(message: ChatMessage) {
    val context = LocalContext.current
    val isUser = message.role == "user"
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            color = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            contentColor = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.widthIn(max = 340.dp)
        ) {
            SelectionContainer {
                FormattedText(message.content, Modifier.padding(14.dp))
            }
        }
        if (!isUser) {
            TextButton(onClick = { copyToClipboard(context, message.content) }) {
                Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.size(6.dp))
                Text("Copier", fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun TypingIndicator() {
    val transition = rememberInfiniteTransition(label = "typing")
    Row(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        for (i in 0 until 3) {
            val a by transition.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(600, delayMillis = i * 150), RepeatMode.Reverse),
                label = "dot$i"
            )
            Surface(
                modifier = Modifier
                    .size(8.dp)
                    .alpha(a),
                shape = CircleShape,
                color = MaterialTheme.colorScheme.onSurface
            ) {}
        }
    }
}

@Composable
fun ErrorBanner(message: String, onRetry: (() -> Unit)? = null, onDismiss: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.errorContainer,
        contentColor = MaterialTheme.colorScheme.onErrorContainer,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Row(Modifier.padding(start = 14.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(message, fontSize = 13.sp, modifier = Modifier.weight(1f))
            if (onRetry != null) TextButton(onClick = onRetry) { Text("Réessayer") }
            IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = "Fermer") }
        }
    }
}

@Composable
fun ScreenHeader(
    title: String,
    subtitle: String? = null,
    onBack: (() -> Unit)? = null,
    actions: @Composable () -> Unit = {}
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour") }
        } else {
            Spacer(Modifier.size(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        actions()
    }
}
