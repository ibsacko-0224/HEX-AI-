package com.centralhex.hexai.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ChatMessage(
    val role: String,
    val content: String,
    val ts: Long = System.currentTimeMillis()
)

data class Conversation(
    val id: String,
    val title: String,
    val mode: String,
    val messages: List<ChatMessage> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis()
)

/** Préférences simples. Le jeton d'appareil n'est PAS un secret fournisseur (aucune clé IA dans l'app). */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("hexai", Context.MODE_PRIVATE)

    var apiUrl: String
        get() = sp.getString("api_url", "") ?: ""
        set(value) { sp.edit().putString("api_url", value).apply() }

    var token: String
        get() = sp.getString("token", "") ?: ""
        set(value) { sp.edit().putString("token", value).apply() }

    var dark: Boolean
        get() = sp.getBoolean("dark", true)
        set(value) { sp.edit().putBoolean("dark", value).apply() }
}

/** Historique des conversations stocké localement dans un fichier JSON. */
class LocalStore(context: Context) {
    private val file = File(context.filesDir, "conversations.json")

    fun load(): List<Conversation> {
        return try {
            if (!file.exists()) return emptyList()
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val msgs = o.getJSONArray("messages")
                Conversation(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    mode = o.getString("mode"),
                    updatedAt = o.optLong("updatedAt", 0L),
                    messages = (0 until msgs.length()).map { j ->
                        val m = msgs.getJSONObject(j)
                        ChatMessage(m.getString("role"), m.getString("content"), m.optLong("ts", 0L))
                    }
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(list: List<Conversation>) {
        try {
            val arr = JSONArray()
            list.forEach { c ->
                val msgs = JSONArray()
                c.messages.forEach { m ->
                    msgs.put(JSONObject().put("role", m.role).put("content", m.content).put("ts", m.ts))
                }
                arr.put(
                    JSONObject()
                        .put("id", c.id)
                        .put("title", c.title)
                        .put("mode", c.mode)
                        .put("updatedAt", c.updatedAt)
                        .put("messages", msgs)
                )
            }
            val tmp = File(file.parentFile, "conversations.json.tmp")
            tmp.writeText(arr.toString())
            if (!tmp.renameTo(file)) {
                file.writeText(arr.toString())
                tmp.delete()
            }
        } catch (e: Exception) {
            // l'historique est une commodité : on n'interrompt pas l'utilisateur
        }
    }
}
