# HEX-AI — Backend

Proxy sécurisé entre l'application Android et OpenRouter. Node.js ≥ 20 (22 recommandé), **sans framework** : le serveur utilise le module `http` de Node (aucune dépendance obligatoire). Seule l'extraction PDF utilise `pdfjs-dist` (dépendance optionnelle).

## Lancer en local

```bash
cd backend
cp .env.example .env      # puis remplis OPENROUTER_API_KEY et AUTH_SECRET
npm install
set -a; . ./.env; set +a  # charge les variables (ou configure-les sur ton hébergeur)
npm start
npm test                  # 17 tests avec un faux fournisseur IA
```

## Variables d'environnement (côté serveur uniquement)

| Variable | Rôle |
|---|---|
| `OPENROUTER_API_KEY` | Clé OpenRouter. Jamais renvoyée ni journalisée. |
| `AUTH_SECRET` | Secret (≥ 16 caractères) qui signe les jetons d'appareil. |
| `AI_MODEL` | Modèle par défaut (`openrouter/free`). |
| `AI_VISION_MODEL` | Modèle pour les images (doit accepter les images). |
| `PORT`, `TRUST_PROXY` | Port, et `1` derrière un proxy (Render, Railway…). |
| `RATE_LIMIT_PER_MIN_IP/DEVICE`, `DAILY_LIMIT_PER_DEVICE`, `REGISTER_LIMIT_PER_HOUR_IP` | Limites anti-abus. |

## API

Toutes les routes sauf `health` et `auth/register` exigent `Authorization: Bearer <jeton>`.

| Méthode | Route | Rôle |
|---|---|---|
| GET | `/api/health` | État du serveur (`aiConfigured` vrai/faux, sans clé). |
| POST | `/api/auth/register` | Délivre un jeton d'appareil (valable 90 jours). |
| POST | `/api/chat` | `{mode, messages, language?}` — modes : `chat`, `dev`, `ideas`, `writing`, `translate`. |
| POST | `/api/documents/extract` | `{filename, dataBase64}` — PDF, TXT, DOCX (8 Mo max). |
| POST | `/api/documents/ask` | `{text, question?}` — résumé / questions sur le texte extrait. |
| POST | `/api/vision` | `{imageBase64, question?}` — PNG/JPEG/WEBP/GIF (5 Mo max). |
| POST | `/api/images/generate` | Répond **501** : aucun fournisseur d'images n'est connecté. |
| GET/POST/DELETE | `/api/conversations[/:id]`, `POST /api/conversations/:id/messages` | Conversations stockées côté serveur, par appareil. |

## Déploiement

1. Crée un service Web Node sur ton hébergeur (Dockerfile fourni, ou `npm install` + `npm start` avec le dossier `backend` comme racine).
2. Saisis les variables ci-dessus dans l'interface de l'hébergeur (jamais dans le dépôt).
3. Mets `TRUST_PROXY=1` si le service est derrière un proxy.
4. Vérifie `https://TON-DOMAINE/api/health`, puis donne cette adresse à l'application (Paramètres) ou à GitHub (variable `HEX_API_URL`).

Notes : sur les offres gratuites, le disque est souvent effacé à chaque redémarrage (les conversations *côté serveur* et `data/` sont perdues ; l'application Android garde elle-même son historique) et le service peut s'endormir.
