'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert');
const http = require('http');
const os = require('os');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { loadConfig } = require('../src/config');
const { createServer } = require('../src/server');

const SECRET_KEY = 'sk-or-TEST-SECRET-KEY-123456';
let mock, mockPort, app, base, token, lastProviderBody, lastProviderAuth, providerMode = 'ok';

const listen = (srv) => new Promise((r) => srv.listen(0, '127.0.0.1', () => r(srv.address().port)));

async function api(method, p, body, tok = token, extraHeaders = {}) {
  const headers = { ...extraHeaders };
  if (tok) headers.Authorization = `Bearer ${tok}`;
  let payload;
  if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = typeof body === 'string' ? body : JSON.stringify(body); }
  const r = await fetch(base + p, { method, headers, body: payload });
  const text = await r.text();
  let json = null; try { json = JSON.parse(text); } catch {}
  return { status: r.status, json, text };
}

// ZIP minimal pour fabriquer un .docx de test
function makeZip(name, content) {
  const data = Buffer.from(content);
  const comp = zlib.deflateRawSync(data);
  const nameB = Buffer.from(name);
  const local = Buffer.alloc(30); local.writeUInt32LE(0x04034b50, 0); local.writeUInt16LE(20, 4); local.writeUInt16LE(8, 8);
  local.writeUInt32LE(comp.length, 18); local.writeUInt32LE(data.length, 22); local.writeUInt16LE(nameB.length, 26);
  const cen = Buffer.alloc(46); cen.writeUInt32LE(0x02014b50, 0); cen.writeUInt16LE(20, 4); cen.writeUInt16LE(20, 6); cen.writeUInt16LE(8, 10);
  cen.writeUInt32LE(comp.length, 20); cen.writeUInt32LE(data.length, 24); cen.writeUInt16LE(nameB.length, 28); cen.writeUInt32LE(0, 42);
  const localPart = Buffer.concat([local, nameB, comp]);
  const cenPart = Buffer.concat([cen, nameB]);
  const eocd = Buffer.alloc(22); eocd.writeUInt32LE(0x06054b50, 0); eocd.writeUInt16LE(1, 8); eocd.writeUInt16LE(1, 10);
  eocd.writeUInt32LE(cenPart.length, 12); eocd.writeUInt32LE(localPart.length, 16);
  return Buffer.concat([localPart, cenPart, eocd]);
}

before(async () => {
  mock = http.createServer((req, res) => {
    let b = ''; req.on('data', (c) => (b += c));
    req.on('end', () => {
      lastProviderAuth = req.headers.authorization; lastProviderBody = JSON.parse(b || '{}');
      if (providerMode === 'rate') { res.writeHead(429, { 'Content-Type': 'application/json' }); return res.end('{"error":{"message":"slow down"}}'); }
      if (providerMode === 'novision') { res.writeHead(404, { 'Content-Type': 'application/json' }); return res.end('{"error":{"message":"No endpoints found that support image input"}}'); }
      if (providerMode === 'auth') { res.writeHead(401, { 'Content-Type': 'application/json' }); return res.end(`{"error":{"message":"bad key ${SECRET_KEY}"}}`); }
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ model: 'mock/model', choices: [{ message: { content: 'Réponse simulée' } }] }));
    });
  });
  mockPort = await listen(mock);
  const config = loadConfig({
    OPENROUTER_API_KEY: SECRET_KEY, OPENROUTER_URL: `http://127.0.0.1:${mockPort}/v1/chat/completions`,
    AUTH_SECRET: 'a'.repeat(40), DATA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'hexai-')),
    RATE_LIMIT_PER_MIN_DEVICE: '1000', DAILY_LIMIT_PER_DEVICE: '1000'
  });
  app = createServer(config);
  base = `http://127.0.0.1:${await listen(app)}`;
  token = (await api('POST', '/api/auth/register', {}, null)).json.token;
});

after(() => { app.close(); mock.close(); });

test('health : OK et sans clé', async () => {
  const r = await api('GET', '/api/health', undefined, null);
  assert.equal(r.status, 200); assert.equal(r.json.aiConfigured, true);
  assert.ok(!r.text.includes(SECRET_KEY));
});

test('sécurité : en-têtes présents', async () => {
  const r = await fetch(base + '/api/health');
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
});

test('auth : sans jeton ou jeton falsifié = 401', async () => {
  assert.equal((await api('POST', '/api/chat', { messages: [{ role: 'user', content: 'x' }] }, null)).status, 401);
  const forged = token.slice(0, -3) + 'abc';
  assert.equal((await api('POST', '/api/chat', { messages: [{ role: 'user', content: 'x' }] }, forged)).status, 401);
});

test('chat : réponse, prompt système, clé envoyée seulement au fournisseur', async () => {
  providerMode = 'ok';
  const r = await api('POST', '/api/chat', { mode: 'translate', language: 'espagnol', messages: [{ role: 'user', content: 'Bonjour' }] });
  assert.equal(r.status, 200); assert.equal(r.json.reply, 'Réponse simulée');
  assert.equal(lastProviderAuth, `Bearer ${SECRET_KEY}`);
  assert.equal(lastProviderBody.messages[0].role, 'system');
  assert.match(lastProviderBody.messages[0].content, /espagnol/);
  assert.equal(lastProviderBody.model, 'openrouter/free');
  assert.ok(!r.text.includes(SECRET_KEY));
});

test('chat : validation des entrées', async () => {
  const bads = [
    { messages: [] }, { messages: 'x' }, { mode: 'hack', messages: [{ role: 'user', content: 'a' }] },
    { messages: [{ role: 'system', content: 'a' }] }, { messages: [{ role: 'user', content: 'a'.repeat(9000) }] },
    { messages: [{ role: 'assistant', content: 'a' }] }, { mode: 'translate', language: 'x<script>', messages: [{ role: 'user', content: 'a' }] }
  ];
  for (const b of bads) assert.equal((await api('POST', '/api/chat', b)).status, 400, JSON.stringify(b).slice(0, 60));
  assert.equal((await api('POST', '/api/chat', '{pas du json')).status, 400);
});

test('chat : corps trop gros = 413', async () => {
  const r = await api('POST', '/api/chat', { messages: [{ role: 'user', content: 'a'.repeat(300 * 1024) }] });
  assert.equal(r.status, 413);
});

test('erreurs fournisseur : 429, auth masquée (clé jamais renvoyée)', async () => {
  providerMode = 'rate';
  assert.equal((await api('POST', '/api/chat', { messages: [{ role: 'user', content: 'a' }] })).status, 429);
  providerMode = 'auth';
  const r = await api('POST', '/api/chat', { messages: [{ role: 'user', content: 'a' }] });
  assert.equal(r.status, 502); assert.ok(!r.text.includes(SECRET_KEY));
  providerMode = 'ok';
});

test('documents : TXT et DOCX extraits, formats refusés', async () => {
  const t = await api('POST', '/api/documents/extract', { filename: 'note.txt', dataBase64: Buffer.from('Bonjour document').toString('base64') });
  assert.equal(t.status, 200); assert.equal(t.json.text, 'Bonjour document');
  const xml = '<w:document><w:body><w:p><w:r><w:t>Titre &amp; test</w:t></w:r></w:p><w:p><w:r><w:t>Deuxième ligne</w:t></w:r></w:p></w:body></w:document>';
  const d = await api('POST', '/api/documents/extract', { filename: 'a.docx', dataBase64: makeZip('word/document.xml', xml).toString('base64') });
  assert.equal(d.status, 200); assert.equal(d.json.text, 'Titre & test\nDeuxième ligne');
  assert.equal((await api('POST', '/api/documents/extract', { filename: 'a.exe', dataBase64: 'AAAA' })).status, 415);
  assert.equal((await api('POST', '/api/documents/extract', { filename: 'a.docx', dataBase64: Buffer.from('pas un zip').toString('base64') })).status, 422);
  assert.equal((await api('POST', '/api/documents/extract', { filename: 'a.txt', dataBase64: '!!!' })).status, 400);
});

test('documents : PDF (si pdfjs-dist installé)', async (t) => {
  let ok = true; try { await import('pdfjs-dist/legacy/build/pdf.mjs'); } catch { ok = false; }
  if (!ok) return t.skip('pdfjs-dist non installé');
  const objs = ['<< /Type /Catalog /Pages 2 0 R >>', '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 200] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>',
    null, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>'];
  const stream = 'BT /F1 18 Tf 20 100 Td (Hello HEX PDF) Tj ET';
  objs[3] = `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`;
  let pdf = '%PDF-1.4\n'; const offs = [];
  objs.forEach((o, i) => { offs.push(pdf.length); pdf += `${i + 1} 0 obj\n${o}\nendobj\n`; });
  const xref = pdf.length;
  pdf += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n` + offs.map((o) => String(o).padStart(10, '0') + ' 00000 n \n').join('') +
    `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  const r = await api('POST', '/api/documents/extract', { filename: 'x.pdf', dataBase64: Buffer.from(pdf).toString('base64') });
  assert.equal(r.status, 200, r.text); assert.match(r.json.text, /Hello HEX PDF/);
});

test('documents/ask : le texte du document est transmis au modèle', async () => {
  const r = await api('POST', '/api/documents/ask', { text: 'Contenu secret du contrat', question: 'De quoi parle-t-il ?' });
  assert.equal(r.status, 200);
  assert.match(lastProviderBody.messages[0].content, /Contenu secret du contrat/);
  assert.equal(lastProviderBody.messages[1].content, 'De quoi parle-t-il ?');
});

test('vision : PNG accepté, faux fichier refusé, modèle sans vision = 422', async () => {
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
  const ok = await api('POST', '/api/vision', { imageBase64: png.toString('base64'), question: 'Que vois-tu ?' });
  assert.equal(ok.status, 200);
  const part = lastProviderBody.messages[0].content;
  assert.equal(part[1].type, 'image_url'); assert.match(part[1].image_url.url, /^data:image\/png;base64,/);
  assert.equal((await api('POST', '/api/vision', { imageBase64: Buffer.from('texte').toString('base64') })).status, 415);
  providerMode = 'novision';
  assert.equal((await api('POST', '/api/vision', { imageBase64: png.toString('base64') })).json.error.code, 'model_no_vision');
  providerMode = 'ok';
});

test('génération d\'images : 501 honnête', async () => {
  const r = await api('POST', '/api/images/generate', { prompt: 'chat' });
  assert.equal(r.status, 501); assert.equal(r.json.error.code, 'image_generation_not_configured');
});

test('conversations : créer, discuter, lister, isoler par appareil, supprimer', async () => {
  const c = (await api('POST', '/api/conversations', { title: 'Test', mode: 'dev' })).json;
  const m = await api('POST', `/api/conversations/${c.id}/messages`, { content: 'Salut' });
  assert.equal(m.status, 200); assert.equal(m.json.conversation.messageCount, 2);
  assert.equal((await api('GET', '/api/conversations')).json.conversations.length, 1);
  assert.equal((await api('GET', `/api/conversations/${c.id}`)).json.messages.length, 2);
  const other = (await api('POST', '/api/auth/register', {}, null)).json.token;
  assert.equal((await api('GET', `/api/conversations/${c.id}`, undefined, other)).status, 404);
  assert.equal((await api('DELETE', `/api/conversations/${c.id}`)).status, 200);
  assert.equal((await api('GET', `/api/conversations/${c.id}`)).status, 404);
});

test('routes inconnues et méthodes interdites', async () => {
  assert.equal((await api('GET', '/api/nope', undefined, null)).status, 404);
  assert.equal((await api('GET', '/api/chat')).status, 405);
});

test('limitation de débit par appareil', async () => {
  const cfg = loadConfig({ OPENROUTER_API_KEY: 'k', AUTH_SECRET: 'b'.repeat(40), DATA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'hexai-')), RATE_LIMIT_PER_MIN_DEVICE: '3', RATE_LIMIT_PER_MIN_IP: '1000', OPENROUTER_URL: `http://127.0.0.1:${mockPort}/x` });
  const s = createServer(cfg); const p = await listen(s); const b = `http://127.0.0.1:${p}`;
  const t = (await (await fetch(b + '/api/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })).json()).token;
  const codes = [];
  for (let i = 0; i < 5; i++) codes.push((await fetch(b + '/api/conversations', { headers: { Authorization: `Bearer ${t}` } })).status);
  s.close();
  assert.deepEqual(codes, [200, 200, 200, 429, 429]);
});

test('quota journalier', async () => {
  const cfg = loadConfig({ OPENROUTER_API_KEY: 'k', AUTH_SECRET: 'c'.repeat(40), DATA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'hexai-')), DAILY_LIMIT_PER_DEVICE: '2', OPENROUTER_URL: `http://127.0.0.1:${mockPort}/x` });
  const s = createServer(cfg); const p = await listen(s); const b = `http://127.0.0.1:${p}`;
  const t = (await (await fetch(b + '/api/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })).json()).token;
  const codes = [];
  for (let i = 0; i < 3; i++) codes.push((await fetch(b + '/api/chat', { method: 'POST', headers: { Authorization: `Bearer ${t}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: [{ role: 'user', content: 'a' }] }) })).status);
  s.close();
  assert.deepEqual(codes, [200, 200, 429]);
});

test('sans clé fournisseur : 503 clair', async () => {
  const cfg = loadConfig({ AUTH_SECRET: 'd'.repeat(40), DATA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'hexai-')) });
  const s = createServer(cfg); const p = await listen(s); const b = `http://127.0.0.1:${p}`;
  const t = (await (await fetch(b + '/api/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })).json()).token;
  const r = await fetch(b + '/api/chat', { method: 'POST', headers: { Authorization: `Bearer ${t}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: [{ role: 'user', content: 'a' }] }) });
  s.close();
  assert.equal(r.status, 503);
});
