'use strict';
const http = require('http');
const { loadConfig } = require('./config');
const { HttpError, sendJson, readJson } = require('./lib/http');
const { RateLimiter, DailyQuota } = require('./lib/rateLimit');
const { verifyToken } = require('./lib/auth');
const { createAiService } = require('./services/ai');
const { ConversationStore } = require('./services/store');
const { buildRoutes } = require('./routes');

function compile(route) {
  const keys = [];
  const re = new RegExp('^' + route.path.replace(/:([a-zA-Z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
  return { ...route, re, keys };
}

function createServer(config = loadConfig()) {
  const ai = createAiService(config);
  const store = new ConversationStore(config.dataDir);
  const routes = buildRoutes({ config, ai, store }).map(compile);
  const ipLimiter = new RateLimiter(config.limits.ipPerMin, 60 * 1000);
  const deviceLimiter = new RateLimiter(config.limits.devicePerMin, 60 * 1000);
  const registerLimiter = new RateLimiter(config.limits.registerPerHourIp, 60 * 60 * 1000);
  const dailyQuota = new DailyQuota(config.limits.dailyPerDevice);

  const clientIp = (req) => {
    if (config.trustProxy) {
      const xff = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
      if (xff) return xff;
    }
    return req.socket.remoteAddress || 'unknown';
  };

  const server = http.createServer(async (req, res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Content-Security-Policy', "default-src 'none'");
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
    try {
      if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
      const pathname = new URL(req.url, 'http://localhost').pathname;
      let matched = null;
      let params = {};
      let pathExists = false;
      for (const r of routes) {
        const m = r.re.exec(pathname);
        if (!m) continue;
        pathExists = true;
        if (r.method !== req.method) continue;
        matched = r;
        params = {};
        r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
        break;
      }
      if (!matched) {
        throw pathExists ? new HttpError(405, 'method_not_allowed', 'Méthode non autorisée.') : new HttpError(404, 'not_found', 'Route introuvable.');
      }
      const ip = clientIp(req);
      if (!ipLimiter.take(ip)) throw new HttpError(429, 'rate_limited', 'Trop de requêtes. Réessaie dans une minute.');
      if (matched.ipRegisterLimit && !registerLimiter.take(ip)) throw new HttpError(429, 'rate_limited', "Trop d'inscriptions depuis cette adresse. Réessaie plus tard.");

      let device = null;
      if (matched.auth) {
        const h = String(req.headers.authorization || '');
        device = h.startsWith('Bearer ') ? verifyToken(config.authSecret, h.slice(7)) : null;
        if (!device) throw new HttpError(401, 'unauthorized', 'Authentification requise ou expirée.');
        if (!deviceLimiter.take(device.id)) throw new HttpError(429, 'rate_limited', 'Trop de requêtes. Ralentis un peu.');
      }
      const body = matched.body ? await readJson(req, matched.body) : {};
      const out = await matched.handler({ req, body, params, device, config, dailyQuota });
      sendJson(res, out.status || 200, out.body);
    } catch (e) {
      if (e instanceof HttpError) return sendJson(res, e.status, { error: { code: e.code, message: e.message } });
      console.error('[server] erreur interne:', e && e.message);
      sendJson(res, 500, { error: { code: 'internal_error', message: 'Erreur interne du serveur.' } });
    }
  });

  server.keepAliveTimeout = 65000;
  server.on('close', () => { ipLimiter.stop(); deviceLimiter.stop(); registerLimiter.stop(); store.flush(); });
  server.store = store;
  return server;
}

if (require.main === module) {
  const config = loadConfig();
  if (config.ephemeralSecret) console.warn('[config] AUTH_SECRET absent/trop court : secret temporaire (les jetons seront invalidés au redémarrage).');
  if (!config.openrouterKey) console.warn('[config] OPENROUTER_API_KEY absente : les routes IA répondront 503.');
  createServer(config).listen(config.port, () => console.log(`HEX-AI backend prêt sur le port ${config.port}`));
}

module.exports = { createServer };
