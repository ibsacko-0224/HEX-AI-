'use strict';
const crypto = require('crypto');
const path = require('path');

const int = (v, d) => {
  const n = parseInt(v, 10);
  return Number.isFinite(n) && n > 0 ? n : d;
};

function loadConfig(env = process.env) {
  let authSecret = env.AUTH_SECRET || '';
  let ephemeralSecret = false;
  if (authSecret.length < 16) {
    authSecret = crypto.randomBytes(32).toString('hex');
    ephemeralSecret = true;
  }
  return {
    port: int(env.PORT, 3000),
    openrouterKey: env.OPENROUTER_API_KEY || '',
    openrouterUrl: env.OPENROUTER_URL || 'https://openrouter.ai/api/v1/chat/completions',
    model: env.AI_MODEL || 'openrouter/free',
    visionModel: env.AI_VISION_MODEL || env.AI_MODEL || 'openrouter/free',
    authSecret,
    ephemeralSecret,
    trustProxy: env.TRUST_PROXY === '1',
    dataDir: env.DATA_DIR || path.join(__dirname, '..', 'data'),
    aiTimeoutMs: int(env.AI_TIMEOUT_MS, 60000),
    limits: {
      ipPerMin: int(env.RATE_LIMIT_PER_MIN_IP, 120),
      devicePerMin: int(env.RATE_LIMIT_PER_MIN_DEVICE, 30),
      dailyPerDevice: int(env.DAILY_LIMIT_PER_DEVICE, 300),
      registerPerHourIp: int(env.REGISTER_LIMIT_PER_HOUR_IP, 20),
      jsonBytes: 200 * 1024,
      docBytes: 8 * 1024 * 1024,
      imageBytes: 5 * 1024 * 1024,
      messageChars: 8000,
      totalChars: 40000,
      maxMessages: 50,
      docTextChars: 60000
    },
    tokenTtlDays: 90
  };
}

module.exports = { loadConfig };
