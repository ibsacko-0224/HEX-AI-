'use strict';
const zlib = require('zlib');
const { HttpError } = require('../lib/http');

// ---- Lecture minimale d'un ZIP (suffisant pour extraire word/document.xml d'un .docx)
function readZipEntry(buf, wanted) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('zip');
  const count = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('zip');
    const method = buf.readUInt16LE(p + 10);
    const csize = buf.readUInt32LE(p + 20);
    const nameLen = buf.readUInt16LE(p + 28);
    const extraLen = buf.readUInt16LE(p + 30);
    const commentLen = buf.readUInt16LE(p + 32);
    const localOff = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nameLen);
    if (name === wanted) {
      const lNameLen = buf.readUInt16LE(localOff + 26);
      const lExtraLen = buf.readUInt16LE(localOff + 28);
      const start = localOff + 30 + lNameLen + lExtraLen;
      const data = buf.subarray(start, start + csize);
      if (method === 0) return data;
      if (method === 8) return zlib.inflateRawSync(data, { maxOutputLength: 50 * 1024 * 1024 });
      throw new Error('zip-method');
    }
    p += 46 + nameLen + extraLen + commentLen;
  }
  return null;
}

const decodeEntities = (s) =>
  s
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(parseInt(d, 10)))
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&amp;/g, '&');

function docxToText(buf) {
  let xml;
  try {
    const entry = readZipEntry(buf, 'word/document.xml');
    if (!entry) throw new Error('missing');
    xml = entry.toString('utf8');
  } catch {
    throw new HttpError(422, 'invalid_document', "Ce fichier .docx est illisible ou corrompu.");
  }
  const text = xml
    .replace(/<w:tab\s*\/>/g, '\t')
    .replace(/<w:(br|cr)\b[^>]*\/>/g, '\n')
    .replace(/<\/w:p>/g, '\n')
    .replace(/<[^>]+>/g, '');
  return decodeEntities(text);
}

async function pdfToText(buf) {
  let pdfjs;
  try {
    pdfjs = await import('pdfjs-dist/legacy/build/pdf.mjs');
  } catch {
    throw new HttpError(501, 'pdf_unavailable', "L'extraction PDF n'est pas installée sur ce serveur (npm install pdfjs-dist).");
  }
  try {
    const doc = await pdfjs.getDocument({ data: new Uint8Array(buf), useSystemFonts: true, isEvalSupported: false }).promise;
    const pages = Math.min(doc.numPages, 200);
    const out = [];
    for (let i = 1; i <= pages; i++) {
      const page = await doc.getPage(i);
      const content = await page.getTextContent();
      out.push(content.items.map((it) => it.str + (it.hasEOL ? '\n' : '')).join(' '));
    }
    return out.join('\n\n');
  } catch {
    throw new HttpError(422, 'invalid_document', 'Ce PDF est illisible, protégé ou ne contient pas de texte (scan).');
  }
}

async function extractText(filename, buffer, maxChars) {
  const ext = String(filename || '').toLowerCase().split('.').pop();
  let text;
  if (ext === 'txt' || ext === 'md' || ext === 'csv' || ext === 'json') text = buffer.toString('utf8');
  else if (ext === 'docx') text = docxToText(buffer);
  else if (ext === 'pdf') {
    if (buffer.subarray(0, 5).toString('latin1') !== '%PDF-') throw new HttpError(422, 'invalid_document', "Ce fichier n'est pas un PDF valide.");
    text = await pdfToText(buffer);
  } else {
    throw new HttpError(415, 'unsupported_file', 'Formats pris en charge : PDF, TXT, DOCX.');
  }
  text = text.replace(/\r\n/g, '\n').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  if (!text) throw new HttpError(422, 'empty_document', 'Aucun texte trouvé dans ce document.');
  const truncated = text.length > maxChars;
  return { text: truncated ? text.slice(0, maxChars) : text, truncated, chars: text.length, type: ext };
}

module.exports = { extractText, docxToText };
