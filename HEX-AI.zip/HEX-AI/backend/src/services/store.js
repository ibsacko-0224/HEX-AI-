'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Stockage JSON simple par appareil : { [deviceId]: { [convId]: conversation } }
class ConversationStore {
  constructor(dir) {
    this.file = path.join(dir, 'conversations.json');
    this.data = {};
    this.timer = null;
    try {
      fs.mkdirSync(dir, { recursive: true });
      this.data = JSON.parse(fs.readFileSync(this.file, 'utf8'));
    } catch {
      this.data = {};
    }
  }
  bucket(deviceId) {
    if (!this.data[deviceId]) this.data[deviceId] = {};
    return this.data[deviceId];
  }
  list(deviceId) {
    return Object.values(this.bucket(deviceId))
      .map((c) => ({ id: c.id, title: c.title, mode: c.mode, updatedAt: c.updatedAt, messageCount: c.messages.length }))
      .sort((a, b) => b.updatedAt - a.updatedAt);
  }
  count(deviceId) {
    return Object.keys(this.bucket(deviceId)).length;
  }
  create(deviceId, { title, mode }) {
    const now = Date.now();
    const conv = { id: crypto.randomUUID(), title, mode, createdAt: now, updatedAt: now, messages: [] };
    this.bucket(deviceId)[conv.id] = conv;
    this.save();
    return conv;
  }
  get(deviceId, id) {
    return this.bucket(deviceId)[id] || null;
  }
  remove(deviceId, id) {
    const b = this.bucket(deviceId);
    if (!b[id]) return false;
    delete b[id];
    this.save();
    return true;
  }
  touch() {
    this.save();
  }
  save() {
    if (this.timer) return;
    this.timer = setTimeout(() => {
      this.timer = null;
      this.flush();
    }, 200);
    this.timer.unref();
  }
  flush() {
    try {
      const tmp = this.file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(this.data));
      fs.renameSync(tmp, this.file);
    } catch (e) {
      console.error('[store] écriture impossible');
    }
  }
}

module.exports = { ConversationStore };
