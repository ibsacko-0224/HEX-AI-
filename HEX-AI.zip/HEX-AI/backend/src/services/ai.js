'use strict';
const { HttpError } = require('../lib/http');

// Appelle OpenRouter. La clé n'est jamais journalisée ni renvoyée.
function createAiService(config) {
  async function complete({ messages, model }) {
    if (!config.openrouterKey) {
      throw new HttpError(503, 'ai_not_configured', "Le serveur IA n'est pas configuré (clé fournisseur manquante).");
    }
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), config.aiTimeoutMs);
    let resp;
    try {
      resp = await fetch(config.openrouterUrl, {
        method: 'POST',
        signal: controller.signal,
        headers: {
          Authorization: `Bearer ${config.openrouterKey}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': 'https://github.com/central-hex/HEX-AI',
          'X-Title': 'HEX-AI'
        },
        body: JSON.stringify({ model: model || config.model, messages, max_tokens: 2048 })
      });
    } catch (e) {
      if (e && e.name === 'AbortError') {
        throw new HttpError(504, 'provider_timeout', "Le fournisseur IA n'a pas répondu à temps.");
      }
      throw new HttpError(502, 'provider_unreachable', 'Fournisseur IA injoignable.');
    } finally {
      clearTimeout(timer);
    }

    let data = null;
    let raw = '';
    try {
      raw = await resp.text();
      data = JSON.parse(raw);
    } catch {
      /* corps non JSON */
    }

    if (!resp.ok) {
      const providerMsg = String((data && data.error && data.error.message) || raw || '').slice(0, 300);
      console.error(`[ai] erreur fournisseur HTTP ${resp.status}`); // jamais de clé ni d'en-têtes
      if (resp.status === 429) throw new HttpError(429, 'provider_rate_limited', 'Le modèle est très sollicité. Réessaie dans un instant.');
      if ((resp.status === 400 || resp.status === 404) && /image|vision|multimodal|modalit/i.test(providerMsg)) {
        throw new HttpError(422, 'model_no_vision', "Le modèle configuré n'accepte pas les images.");
      }
      if (resp.status === 401 || resp.status === 403 || resp.status === 402) {
        throw new HttpError(502, 'provider_auth', "Le fournisseur IA a refusé la requête (clé ou crédits). Contacte l'administrateur.");
      }
      throw new HttpError(502, 'provider_error', 'Le fournisseur IA a renvoyé une erreur.');
    }

    const msg = data && data.choices && data.choices[0] && data.choices[0].message;
    let content = msg && msg.content;
    if (Array.isArray(content)) content = content.map((p) => (p && p.text) || '').join('');
    if (typeof content !== 'string' || !content.trim()) {
      throw new HttpError(502, 'empty_reply', "Le modèle n'a renvoyé aucune réponse. Réessaie.");
    }
    return { reply: content.trim(), model: (data && data.model) || model || config.model };
  }
  return { complete };
}

module.exports = { createAiService };
