'use strict';
const { HttpError } = require('./lib/http');
const { issueToken } = require('./lib/auth');
const { systemPrompt, VALID_MODES } = require('./services/prompts');
const { extractText } = require('./services/documents');
const { validateMessages, validateLanguage, decodeBase64, detectImageType, bad } = require('./lib/validate');

function buildRoutes({ config, ai, store }) {
  const L = config.limits;
  const docJson = Math.ceil((L.docBytes * 4) / 3) + 4096;
  const imgJson = Math.ceil((L.imageBytes * 4) / 3) + 4096;

  const withSystem = (mode, language, messages) => [{ role: 'system', content: systemPrompt(mode, language) }, ...messages];
  const aiQuota = (ctx) => {
    if (!ctx.dailyQuota.take(ctx.device.id)) {
      throw new HttpError(429, 'daily_limit', "Limite quotidienne atteinte pour cet appareil. Reviens demain.");
    }
  };

  return [
    {
      method: 'GET', path: '/api/health', auth: false,
      handler: async () => ({
        body: { status: 'ok', service: 'hex-ai-backend', aiConfigured: Boolean(config.openrouterKey), model: config.model, time: new Date().toISOString() }
      })
    },
    {
      method: 'POST', path: '/api/auth/register', auth: false, ipRegisterLimit: true, body: L.jsonBytes,
      handler: async () => {
        const t = issueToken(config.authSecret, config.tokenTtlDays);
        return { status: 201, body: { token: t.token, expiresAt: t.expiresAt } };
      }
    },
    {
      method: 'POST', path: '/api/chat', auth: true, body: L.jsonBytes,
      handler: async (ctx) => {
        const { mode = 'chat', messages, language } = ctx.body;
        if (!VALID_MODES.includes(mode)) throw bad(`Mode inconnu. Modes : ${VALID_MODES.join(', ')}.`);
        const clean = validateMessages(messages, L);
        const lang = validateLanguage(language);
        aiQuota(ctx);
        const out = await ai.complete({ messages: withSystem(mode, lang, clean) });
        return { body: out };
      }
    },
    {
      method: 'POST', path: '/api/documents/extract', auth: true, body: docJson,
      handler: async (ctx) => {
        const { filename, dataBase64 } = ctx.body;
        if (typeof filename !== 'string' || !filename || filename.length > 200) throw bad('Nom de fichier invalide.');
        const buf = decodeBase64(dataBase64, L.docBytes, 'Document');
        const r = await extractText(filename, buf, L.docTextChars);
        return { body: r };
      }
    },
    {
      method: 'POST', path: '/api/documents/ask', auth: true, body: L.jsonBytes + L.docTextChars * 4,
      handler: async (ctx) => {
        const { text, question } = ctx.body;
        if (typeof text !== 'string' || !text.trim() || text.length > L.docTextChars) throw bad(`"text" requis (max ${L.docTextChars} caractères).`);
        const q = typeof question === 'string' && question.trim() ? question.trim() : 'Fais un résumé structuré de ce document (points clés).';
        if (q.length > L.messageChars) throw bad('Question trop longue.');
        aiQuota(ctx);
        const sys =
          "Tu analyses un document fourni par l'utilisateur. Réponds uniquement à partir de son contenu ; " +
          "si l'information n'y figure pas, dis-le. Réponds dans la langue de la question.\n\n--- DOCUMENT ---\n" + text;
        const out = await ai.complete({ messages: [{ role: 'system', content: sys }, { role: 'user', content: q }] });
        return { body: out };
      }
    },
    {
      method: 'POST', path: '/api/vision', auth: true, body: imgJson,
      handler: async (ctx) => {
        const { imageBase64, question } = ctx.body;
        const buf = decodeBase64(imageBase64, L.imageBytes, 'Image');
        const mime = detectImageType(buf);
        if (!mime) throw new HttpError(415, 'unsupported_image', 'Formats pris en charge : PNG, JPEG, WEBP, GIF.');
        const q = typeof question === 'string' && question.trim() ? question.trim() : "Décris cette image en détail.";
        if (q.length > L.messageChars) throw bad('Question trop longue.');
        aiQuota(ctx);
        const content = [
          { type: 'text', text: q },
          { type: 'image_url', image_url: { url: `data:${mime};base64,${buf.toString('base64')}` } }
        ];
        const out = await ai.complete({ model: config.visionModel, messages: [{ role: 'user', content }] });
        return { body: out };
      }
    },
    {
      method: 'POST', path: '/api/images/generate', auth: true, body: L.jsonBytes,
      handler: async () => ({
        status: 501,
        body: { error: { code: 'image_generation_not_configured', message: "La génération d'images n'est pas encore connectée à un fournisseur." } }
      })
    },
    // ---- Conversations (stockées côté serveur, par appareil)
    {
      method: 'GET', path: '/api/conversations', auth: true,
      handler: async (ctx) => ({ body: { conversations: store.list(ctx.device.id) } })
    },
    {
      method: 'POST', path: '/api/conversations', auth: true, body: L.jsonBytes,
      handler: async (ctx) => {
        const { title = 'Nouvelle conversation', mode = 'chat' } = ctx.body;
        if (typeof title !== 'string' || title.length > 100) throw bad('Titre invalide.');
        if (!VALID_MODES.includes(mode) || mode === 'translate') throw bad('Mode invalide.');
        if (store.count(ctx.device.id) >= 100) throw new HttpError(409, 'too_many_conversations', 'Maximum 100 conversations. Supprime-en pour continuer.');
        return { status: 201, body: store.create(ctx.device.id, { title: title.trim() || 'Nouvelle conversation', mode }) };
      }
    },
    {
      method: 'GET', path: '/api/conversations/:id', auth: true,
      handler: async (ctx) => {
        const c = store.get(ctx.device.id, ctx.params.id);
        if (!c) throw new HttpError(404, 'not_found', 'Conversation introuvable.');
        return { body: c };
      }
    },
    {
      method: 'DELETE', path: '/api/conversations/:id', auth: true,
      handler: async (ctx) => {
        if (!store.remove(ctx.device.id, ctx.params.id)) throw new HttpError(404, 'not_found', 'Conversation introuvable.');
        return { status: 200, body: { deleted: true } };
      }
    },
    {
      method: 'POST', path: '/api/conversations/:id/messages', auth: true, body: L.jsonBytes,
      handler: async (ctx) => {
        const c = store.get(ctx.device.id, ctx.params.id);
        if (!c) throw new HttpError(404, 'not_found', 'Conversation introuvable.');
        if (c.messages.length >= 200) throw new HttpError(409, 'conversation_full', 'Conversation trop longue : crée-en une nouvelle.');
        const history = [...c.messages.slice(-30), { role: 'user', content: ctx.body.content }];
        const clean = validateMessages(history, L);
        aiQuota(ctx);
        const out = await ai.complete({ messages: withSystem(c.mode, undefined, clean) });
        const now = Date.now();
        c.messages.push({ role: 'user', content: clean[clean.length - 1].content, ts: now });
        c.messages.push({ role: 'assistant', content: out.reply, ts: Date.now() });
        if (c.messages.length === 2) c.title = clean[clean.length - 1].content.slice(0, 60);
        c.updatedAt = Date.now();
        store.touch();
        return { body: { reply: out.reply, model: out.model, conversation: { id: c.id, title: c.title, messageCount: c.messages.length } } };
      }
    }
  ];
}

module.exports = { buildRoutes };
